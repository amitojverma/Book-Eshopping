package com.cts.bookShopping.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "addToCart")
@Table(name = "addToCart")
public class AddToCart {
@Id
@GeneratedValue
@Column(name = "cartId")
private int cartId;
@Column(name = "bookName")
private String bookName;
@Column(name = "userId")

private String userId;
@Column(name = "price")
private String price;
@Override
public String toString() {
	return "AddToCart [cartId=" + cartId + ", bookName=" + bookName + ", userId=" + userId + ", price=" + price + "]";
}
public AddToCart(int cartId, String bookName, String userId, String price) {
	super();
	this.cartId = cartId;
	this.bookName = bookName;
	this.userId = userId;
	this.price = price;
}
public int getCartId() {
	return cartId;
}
public void setCartId(int cartId) {
	this.cartId = cartId;
}
public String getBookName() {
	return bookName;
}
public void setBookId(String bookName) {
	this.bookName = bookName;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
public AddToCart() {
}

}