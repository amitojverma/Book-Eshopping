package com.cts.bookShopping.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "orderDetails")
@Table(name = "orderDetails_table")
public class OrderDetails {
	@Id
	@Column(name = "orderId")
	@GeneratedValue
	private int orderId;
	@Column(name = "emailId")
	private String emailId;
	@Column(name = "orderStatus")
	private String orderStatus;
	public OrderDetails() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "OrderDetails [orderId=" + orderId + ", emailId=" + emailId + ", orderStatus=" + orderStatus + "]";
	}
	public OrderDetails(int orderId, String emailId, String orderStatus) {
		super();
		this.orderId = orderId;
		this.emailId = emailId;
		this.orderStatus = orderStatus;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
}
