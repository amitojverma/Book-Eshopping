package com.cts.bookShopping.dao;

import java.util.List;

import com.cts.bookShopping.bean.AddToCart;

public interface AddToCartDAO {
	public String addCartDetails(AddToCart add);
	public List<AddToCart> viewCartDetails(String id); 
	public String deleteCartItem(int id);
	public String totalPrice(String id);
}
